package com.ak.p08;

 class Counterss implements Runnable {

	Storage st;

	public Counterss(Storage st2) {
		st = st2;
	}

	public Counterss(Storages st2) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		synchronized (st) {
			for (int i = 0; i < 10; i++) {
				while (!st.isPrinted()) { 
					try {
						st.wait();
					} catch (Exception e) {
					}
				}
				st.setValue(i);
				st.setPrinted(false);
				st.notify();
			}
		}
	}

}

class Printers implements Runnable {
	Storages st;

	public Printers(Storages st) {
		this.st = st;
	}

	@Override
	public void run() {
		synchronized (st) {
			for (int i = 0; i < 10; i++) {
				while (st.isPrinted()) { 
					try {
						st.wait();
					} catch (Exception e) {
					}
				}
				System.out.println(Thread.currentThread().getName() + " " + st.getValue());
				st.setPrinted(true);
				st.notify();
			}
		}
	}

}

class Storages {
	int i;
	boolean printed = true;

	public Storages() {
		// TODO Auto-generated constructor stub
	}

	public void setValue(int i) {
		this.i = i;
	}

	public int getValue() {
		return this.i;
	}

	public boolean isPrinted() {
		return printed;
	}

	public void setPrinted(boolean p) {
		printed = p;
	}
}

public class AddSynchronization {
	public static void main(String[] args) {
		Storages st = new Storages();
		Counterss c = new Counterss(st);
		Printer p = new Printer(st);
		new Thread(c, "Counter").start();
		new Thread(p, "Printer").start(); 
	}

}


