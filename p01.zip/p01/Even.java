package com.ak.p01;

import java.util.Scanner;

public class Even 
{
	public static void main(String []args)
	   {
	       int n=0,i=0;
          @SuppressWarnings("resource")
		Scanner x = new Scanner(System.in);
          System.out.print("Enter value n : ");
          n = x.nextInt();
          for(i=1; i<=n; i++)
	       {
	           if(i%2==0)
               System.out.print(i+" ");
	       }    
	     System.out.println();
    }
}

