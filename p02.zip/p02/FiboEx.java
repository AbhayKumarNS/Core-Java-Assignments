package com.ak.p02;

import java.util.Scanner;

public class FiboEx 
{
    public static void main(String[] args) 
    {
    	int count = 13, num1 , num2;
    	
    	@SuppressWarnings("resource")
		Scanner sc= new Scanner(System.in);
    	System.out.println("Enter the first number:");
    	num1 = sc.nextInt();
    	
    	System.out.println("Enter the second number:");
    	num2= sc.nextInt();
        System.out.print("Fibonacci Series of "+count+" numbers:");

        for (int i = 1; i <= count; ++i)
        {
            System.out.print(num1+" ");
            int sumOfPrevTwo = num1 + num2;
            num1 = num2;
            num2 = sumOfPrevTwo;
        }
    }
}

